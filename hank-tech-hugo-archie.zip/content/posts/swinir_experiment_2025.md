---
title: "SwinIR Experiment Log (2025/03/31)"
date: 2025-03-31
tags: ["swinir", "super-resolution", "pytorch"]
---

## 🧠 Environment Check

```bash
python3 --version
nvidia-smi
lsb_release -a
```

## 🧪 Results

| Image       | PSNR (Y) | SSIM (Y) |
|-------------|----------|----------|
| baby        | 33.83 dB | 0.8948   |
| bird        | 35.37 dB | 0.9472   |
| butterfly   | 29.18 dB | 0.9319   |
| head        | 33.00 dB | 0.7982   |
| woman       | 30.84 dB | 0.9163   |
| **Average** | 32.44 dB | 0.8976   |

## 📂 Model Path

```
model_zoo/swinir/002_lightweightSR_DIV2K_s64w8_SwinIR-S_x2.pth
```